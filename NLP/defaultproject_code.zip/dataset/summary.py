import os
import datasets
import itertools
import functools
import torch
from torch.nn.utils.rnn import pad_sequence

def prepare_summary_dataset(tokenizer,
                             dataset_name_or_path: str = "abisee/cnn_dailymail",
                             dataset_subset: str = "3.0.0",
                             context_max_length: int = 896,
                             target_max_length: int = 128,
                             context_column_name: str = "article",
                             target_column_name: str = "highlights",
                             prompt: str = "Context: {context}\n Summary:\n",
                             train_sample_size: int =-1,
                             cache_path:str="cache"):
    if cache_path is not None and os.path.exists(os.path.join(cache_path,"summary")):
        print(f"Using pre-downloaded dataset from {cache_path}.")
        train = datasets.load_from_disk(os.path.join(cache_path,"summary","train"))
        validation = datasets.load_from_disk(os.path.join(cache_path,"summary","eval"))
        return train, validation
    else:
        print(f"Download and prerpocessing dataset from {dataset_name_or_path} on subset {dataset_subset}...")
        dataset = datasets.load_dataset(dataset_name_or_path, dataset_subset)
        if "eval" in dataset:
            validation_split = "eval"
        elif "test" in dataset:
            validation_split = "test"
        else:
            print("Using train split for validation.")
            dataset = datasets.train_test_split(test_size=0.1)
            validation_split = "test"
        
        train = dataset["train"] if train_sample_size == -1 else dataset["train"].select(range(train_sample_size))
        validation = dataset[validation_split]

        processing_lambda = functools.partial(
            _preprocess,
            tokenizer=tokenizer,
            context_column_name=context_column_name,
            target_column_name=target_column_name,
            context_max_length=context_max_length,
            target_max_length=target_max_length,
            prompt=prompt
        )
        train = train.map(
            processing_lambda,
            batched=True,
            remove_columns=train.column_names,
            num_proc=1,
            batch_size=64,
            desc="Preprocessing",
        )
        validation = validation.map(
            processing_lambda,
            batched=True,
            remove_columns=validation.column_names,
            num_proc=1,
            batch_size=64,
            desc="Preprocessing",
        )

        if cache_path is not None:
            os.makedirs(os.path.join(cache_path,"summary"), exist_ok=True)
            print(f"Saving dataset to {cache_path}...")
            train.save_to_disk(os.path.join(cache_path,"summary","train"), max_shard_size="500MB")
            validation.save_to_disk(os.path.join(cache_path,"summary","eval"), max_shard_size="500MB")
        return train, validation

def _preprocess(
    examples,
    tokenizer,
    context_column_name,
    target_column_name,
    context_max_length,
    target_max_length,
    prompt,
):
    input_ids_list = []
    attention_mask_list = []
    labels_list = []

    for context, target in zip(
        examples[context_column_name],
        examples[target_column_name],
    ):
        # 1. Format prompt
        formatted_prompt = prompt.format(context=context)

        # 2. Tokenize prompt (NO special tokens)
        prompt_ids = tokenizer.encode(
            formatted_prompt,
            truncation=True,
            max_length=context_max_length,
            add_special_tokens=False,
        )

        # 3. Tokenize target
        target_ids = tokenizer.encode(
            target,
            truncation=True,
            max_length=target_max_length,
            add_special_tokens=False,
        )

        # 4. Append EOS to target
        target_ids.append(tokenizer.eos_token_id)

        # 5. Combine
        input_ids = prompt_ids + target_ids


        if tokenizer.bos_token_id is not None:
            input_ids = [tokenizer.bos_token_id] + input_ids

        attention_mask = [1] * len(input_ids)

        # 6. Labels: ignore prompt
        labels = [-100] * len(prompt_ids) + target_ids
        if tokenizer.bos_token_id is not None:
            labels = [-100] + labels

        input_ids_list.append(input_ids)
        attention_mask_list.append(attention_mask)
        labels_list.append(labels)

    return {
        "input_ids": input_ids_list,
        "attention_mask": attention_mask_list,
        "labels": labels_list,
    }

def collate_fn_for_summary(batch, tokenizer, pad_to_multiple_of=1024):

    input_ids = [torch.tensor(x["input_ids"], dtype=torch.long) for x in batch]
    attention_mask = [torch.tensor(x["attention_mask"], dtype=torch.long) for x in batch]
    labels = [torch.tensor(x["labels"], dtype=torch.long) for x in batch]

    input_ids = pad_sequence(input_ids, batch_first=True, padding_value=tokenizer.pad_token_id)
    attention_mask = pad_sequence(attention_mask, batch_first=True, padding_value=0)
    labels = pad_sequence(labels, batch_first=True, padding_value=-100)

    return {
        "input_ids": input_ids,
        "attention_mask": attention_mask,
        "labels": labels,
    }
