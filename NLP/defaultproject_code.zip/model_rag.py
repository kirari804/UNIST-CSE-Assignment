from transformers import AutoModelForSequenceClassification, AutoTokenizer
from utils.etc import hit2docdict
import torch
import json
# Modify
class ModelRAG():
    def __init__(self):
        pass

    def set_model(self, model):
        self.model = model

    def set_retriever(self, retriever):
        self.retriever = retriever

    def set_tokenizer(self, tokenizer):
        self.tokenizer = tokenizer

    def search(self, queries, qids, k=5):
        # Use the retriever to get relevant documents
        list_passages = []
        list_scores = []

        # fill here
        ######
        
        #### YOUR CODES; TODO 
        for query in queries:
            # search for the top-k hits for the current query
            hits = self.retriever.search(query, k=k)
            
            # Convert the hit objects to document dictionaries
            passages = [hit2docdict(hit) for hit in hits]
            
            # Extract the retrieval scores
            scores = [float(hit.score) for hit in hits]

            list_passages.append(passages)
            list_scores.append(scores)
        
        ######

        return list_passages, list_scores


    # Modify
    # def make_augmented_inputs_for_generate(self, queries, qids, k=5):
    #     # Get the relevant documents for each query
    #     list_passages, list_scores = self.search(queries, qids, k=k)
        
    #     list_input_text_without_answer = []
    #     # fill here
    #     ######
        
    #     #### YOUR CODES; TODO 

    #     for query, passages in zip(queries, list_passages):
    #         passages = passages[:2]
    #         context_texts = [
    #             f"Title: {doc.get('title', '')}\nPassage: {doc.get('text', doc.get('contents', ''))[:200]}"
    #             for doc in passages
    #         ]
    #         context_block = "\n\n".join(
    #             [f"[Doc {i+1}] {text}" for i, text in enumerate(context_texts)]
    #         )

    #         prompt = (
    #             f"Context:\n{context_block}\n\n"
    #             f"Question: {query}\n"
    #             f"Answer:"
    #         )

    #         list_input_text_without_answer.append(prompt)
        
    #     ######
        
    #     return list_input_text_without_answer

    # Prompt template update for section 4.2.1
    def make_augmented_inputs_for_generate(self, queries, qids, k=5):
        list_passages, list_scores = self.search(queries, qids, k=k)
        list_input_text_without_answer = []
        
        for query, passages in zip(queries, list_passages):
            passages = passages[:2]
            context_texts = [
                f"Title: {doc.get('title', '')}\nPassage: {doc.get('text', doc.get('contents', ''))[:200]}"
                for doc in passages
            ]
            context_block = "\n\n".join([f"[Doc {i+1}] {text}" for i, text in enumerate(context_texts)])

            prompt = (
                "<|begin_of_text|>"
                "<|start_header_id|>system<|end_header_id|>\n\n"
                "You MUST extract the exact answer from the context.\n"
                "Return ONLY the answer span. No explanation.\n"
                "<|eot_id|>"
                "<|start_header_id|>user<|end_header_id|>\n\n"
                f"Context:\n{context_block}\n\n"
                f"Question: {query}\n"
                "<|eot_id|>"
                "<|start_header_id|>assistant<|end_header_id|>\n\n"
            )
            list_input_text_without_answer.append(prompt)
            
        return list_input_text_without_answer

    @torch.no_grad()
    def retrieval_augmented_generate(self, queries, qids,k=5, **kwargs):
        # fill here:
        ######
        
        #### YOUR CODES; TODO 
        #  Get the augmented text prompts
        augmented_prompts = self.make_augmented_inputs_for_generate(queries, qids, k=k)
        
        # 2. Tokenize prompts
        inputs = self.tokenizer(
            augmented_prompts,
            padding=True,
            truncation=True,
            return_tensors="pt"
        )
        ######

        # # Move batch to device
        inputs = {k: v.to(self.model.device) for k, v in inputs.items()}
        outputs = self.model.generate(
            **inputs,
            **kwargs
        )
   
        outputs = outputs[:, inputs['input_ids'].size(1):]

        return outputs

# class ChainOfThoughtRAG(ModelRAG):

#     def make_augmented_inputs_for_generate(self, queries, qids, k=5):
#         list_passages, list_scores = self.search(queries, qids, k=k)
#         list_input_text_without_answer = []
        
#         for query, passages in zip(queries, list_passages):
#             passages = passages[:2]
#             context_texts = [
#                 f"Title: {doc.get('title', '')}\nPassage: {doc.get('text', doc.get('contents', ''))[:200]}"
#                 for doc in passages
#             ]
#             context_block = "\n\n".join([f"[Doc {i+1}] {text}" for i, text in enumerate(context_texts)])
#             prompt = (
#                 "<|begin_of_text|>"
#                 "<|start_header_id|>system<|end_header_id|>\n\n"
#                 "You are a precise question-answering assistant.\n"
#                 "Task: Provide a very brief, single-sentence reasoning step based ONLY on the context, followed immediately by the exact answer span.\n"
#                 "Constraint: The reasoning text MUST be under 15 words.\n"
#                 "Format requirement: You must output your thought, write the label 'Answer:' on a new line, and then provide the short answer phrase.\n\n"
#                 # Active Evaluation Row
#                 "<|start_header_id|>user<|end_header_id|>\n\n"
#                 f"Context:\n{context_block}\n\n"
#                 f"Question: {query}<|eot_id|>"
#                 "<|start_header_id|>assistant<|end_header_id|>\n\n"
#                 "Reasoning: "  # Assistant Pre-fill to anchor the start
#             )
#             list_input_text_without_answer.append(prompt)
            
#         return list_input_text_without_answer

class Compressed_RAG(ModelRAG):
    def compress_passage(self, text, query):
        sentences = text.split(".")
        keywords = query.lower().split()

        scored = []
        for s in sentences:
            # Calculate match density per sentence
            score = sum(k in s.lower() for k in keywords)
            if score > 0:
                scored.append((score, s.strip()))

        # Sort sentences internally by keyword match score
        scored = sorted(scored, key=lambda x: x[0], reverse=True)

        # Keep the top 2 sentences and calculate their combined relevance score
        selected = [s for _, s in scored[:2]]
        combined_score = sum(score for score, _ in scored[:2])

        return ". ".join(selected), combined_score
        
    def make_augmented_inputs_for_generate(self, queries, qids, k=5):
        list_passages, list_scores = self.search(queries, qids, k=k)
        list_input_text_without_answer = []

        for query, passages in zip(queries, list_passages):
            passages = passages[:5]

            compressed_docs = []

            for doc in passages:
                text = doc.get('text', doc.get('contents', ''))
                compressed, doc_score = self.compress_passage(text, query)

                if len(compressed) > 0:
                    compressed_docs.append({
                        "title": doc.get("title", ""),
                        "text": compressed,
                        "score": doc_score
                    })

            # Sort by the highest relevance match score
            compressed_docs = sorted(
                compressed_docs,
                key=lambda x: x["score"],
                reverse=True
            )[:3]


            context_block = "\n\n".join([
                f"[Doc {i+1}] Title: {doc['title']}\nPassage: {doc['text']}"
                for i, doc in enumerate(compressed_docs)
            ])

            prompt = (
                "<|begin_of_text|>"
                "<|start_header_id|>system<|end_header_id|>\n\n"
                "Answer using ONLY the given context.\n"
                "Return a short exact answer.\n"
                "<|eot_id|>"
                "<|start_header_id|>user<|end_header_id|>\n\n"
                f"Context:\n{context_block}\n\n"
                f"Question: {query}\n"
                "<|eot_id|>"
                "<|start_header_id|>assistant<|end_header_id|>\n\n"
            )

            list_input_text_without_answer.append(prompt)

        return list_input_text_without_answer

class CrossEncoder(ModelRAG):
    def __init__(self, reranker_name="cross-encoder/ms-marco-MiniLM-L-6-v2", device="cuda"):
        super().__init__()
        # Load a high-speed, lightweight Cross-Encoder model
        print(f"Loading Cross-Encoder Reranker: {reranker_name}...")
        self.reranker_tokenizer = AutoTokenizer.from_pretrained(reranker_name)
        self.reranker_model = AutoModelForSequenceClassification.from_pretrained(reranker_name).to(device)
        self.reranker_model.eval()
        self.device = device

    def compress_passage(self, text, query):
        sentences = text.split(".")
        keywords = query.lower().split()

        scored = []
        for s in sentences:
            score = sum(k in s.lower() for k in keywords)
            if score > 0:
                scored.append((score, s.strip()))
        scored = sorted(scored, key=lambda x: x[0], reverse=True)
        selected = [s for _, s in scored[:2]]
        
        return ". ".join(selected)
        
    def make_augmented_inputs_for_generate(self, queries, qids, k=500):
        #  Fetch top 10 candidates from Pyserini search
        list_passages, list_scores = self.search(queries, qids, k=k)
        list_input_text_without_answer = []

        for query, passages in zip(queries, list_passages):
            # Unpack document text structures safely using your fixed Java-extractor fields
            docs_to_rerank = []
            for doc in passages:
                text = doc.get('text', doc.get('contents', ''))
                title = doc.get('title', 'Untitled')
                docs_to_rerank.append({"title": title, "text": text})

            if not docs_to_rerank:
                # Fallback safety net if retrieval failed completely
                list_input_text_without_answer.append("")
                continue

            # Pair the current user query against every single retrieved document text
            pairs = [[query, doc["text"]] for doc in docs_to_rerank]
            
            features = self.reranker_tokenizer(
                pairs, 
                padding=True, 
                truncation=True, 
                return_tensors="pt"
            ).to(self.device)

            with torch.no_grad():
                # Compute deep semantic cross-attention compatibility logits
                rerank_scores = self.reranker_model(**features).logits.flatten().tolist()

            # Append calculated semantic scores to document metadata
            for i, score in enumerate(rerank_scores):
                docs_to_rerank[i]["rerank_score"] = score

            # Sort documents by their semantic score, completely replacing basic BM25 order
            reranked_docs = sorted(docs_to_rerank, key=lambda x: x["rerank_score"], reverse=True)

            # Select the top 3 semantically superior documents and compress their text payload
            top_3_docs = reranked_docs[:3]
            compressed_docs = []

            for doc in top_3_docs:
                compressed = self.compress_passage(doc["text"], query)
                if len(compressed) > 0:
                    compressed_docs.append({
                        "title": doc["title"],
                        "text": compressed
                    })

            context_block = "\n\n".join([
                f"[Doc {i+1}] Title: {doc['title']}\nPassage: {doc['text']}"
                for i, doc in enumerate(compressed_docs)
            ])


            prompt = (
                "<|begin_of_text|>"
                "<|start_header_id|>system<|end_header_id|>\n\n"
                "Answer using ONLY the given context.\n"
                "Return a short exact answer.\n"
                "<|eot_id|>"
                "<|start_header_id|>user<|end_header_id|>\n\n"
                f"Context:\n{context_block}\n\n"
                f"Question: {query}\n"
                "<|eot_id|>"
                "<|start_header_id|>start_header_id|>assistant<|end_header_id|>\n\n"
            )

            list_input_text_without_answer.append(prompt)

        return list_input_text_without_answer